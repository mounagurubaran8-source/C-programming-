-- SAVEETHA FINDIT: official messaging + private image access
-- Run once in Supabase SQL Editor.
create table if not exists public.office_messages (
 id uuid primary key default gen_random_uuid(),
 sender_id uuid not null references auth.users(id) on delete cascade,
 department text not null, subject text not null, message text not null,
 status text not null default 'open' check (status in ('open','answered','closed')),
 staff_reply text, replied_by uuid references auth.users(id) on delete set null,
 replied_at timestamptz, created_at timestamptz not null default now()
);
alter table public.office_messages enable row level security;
drop policy if exists "FINDIT message insert own" on public.office_messages;
create policy "FINDIT message insert own" on public.office_messages
for insert to authenticated with check (sender_id = auth.uid());
drop policy if exists "FINDIT message read own or staff" on public.office_messages;
create policy "FINDIT message read own or staff" on public.office_messages
for select to authenticated using (
 sender_id = auth.uid() or exists (
  select 1 from public.profiles p where p.id = auth.uid() and p.role in ('staff','admin')
 )
);
drop policy if exists "FINDIT staff reply" on public.office_messages;
create policy "FINDIT staff reply" on public.office_messages
for update to authenticated
using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role in ('staff','admin')))
with check (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role in ('staff','admin')));

insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('findit-items','findit-items',false,5242880,array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;
drop policy if exists "FINDIT authenticated photo read" on storage.objects;
create policy "FINDIT authenticated photo read" on storage.objects
for select to authenticated using (bucket_id = 'findit-items');
drop policy if exists "FINDIT users upload own photo folder" on storage.objects;
create policy "FINDIT users upload own photo folder" on storage.objects
for insert to authenticated with check (
 bucket_id = 'findit-items' and (storage.foldername(name))[1] = auth.uid()::text
);
