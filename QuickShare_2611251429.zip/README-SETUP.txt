SAVEETHA FINDIT UPGRADE

1. Back up your existing project folder.
2. Replace the matching files in your existing src folder with this package's src files.
3. Copy public/simats-logo.png into your existing public folder.
4. Run supabase/findit-upgrade.sql in Supabase SQL Editor.
5. Confirm the Storage bucket is named findit-items.
6. Run npm run dev.

This package keeps the uploaded source's existing authentication and table names.
The new Contact Officials feature uses office_messages. Students can send messages to
Central Lost & Found Office or listed campus departments and see their own conversations.
Profiles with role staff/admin can view the inbox and reply. It is database-backed, not
instant live chat; refresh to fetch new messages.

Photos remain private and are displayed using signed URLs valid for one hour.
Test with a student and a staff account before deployment. Existing RLS for items,
claims, profiles and handovers is not altered. Never expose a service-role key.
